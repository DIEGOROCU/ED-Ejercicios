/*@ <authors>
 *
 * Nombre, apellidos y usuario del juez (ED-DGxx) de los autores de la solución (sustituye esta línea por esos datos; si sois dos, uno en cada línea).
 *
 *@ </authors> */


/*@ <answer>

  Sustituye este párrafo por una explicación de tu solución y una justificación del coste.
 
 *@ </answer> */


#include <iostream>
#include <fstream>

using namespace std;

// Implementa a continuación la función que resuelve un caso de
// prueba. Puedes utilizar otras funciones auxiliares, pon su
// implementación debajo de la etiqueta <answer>.
//@ <answer>


bool resuelveCaso() {

  // completar
  
  return true;
}


//@ </answer>
// ¡No modificar nada debajo de esta línea!
// ----------------------------------------------------------------

int main() {
#ifndef DOMJUDGE
  std::ifstream in("casos.txt");
  auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif
  
  while (resuelveCaso());

#ifndef DOMJUDGE
  std::cin.rdbuf(cinbuf);
  // Descomentar si se trabaja en Visual Studio
  // system("PAUSE");
#endif
  return 0;
}
